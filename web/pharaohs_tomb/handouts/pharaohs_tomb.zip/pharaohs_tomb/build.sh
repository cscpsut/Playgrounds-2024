#!/bin/bash
sudo docker rmi -f pharaohtomb
sudo docker-compose up --build